Sorted for Android, test build 0.1

BUILD THE APK (about 10 minutes, no Android Studio needed)
1. On github.com create a new repository (private is fine). Upload everything in this folder, including the hidden .github folder, to the top level.
   Easiest: unzip, then drag the files into the repo page ("Add file" > "Upload files"). If .github does not upload, use GitHub Desktop or git push.
2. Open the repo's Actions tab, choose "Build APK", click "Run workflow".
3. When it turns green, open the run and download the artifact "sorted-debug-apk". Unzip it to get app-debug.apk.
   If the build fails, open the failed step and send me the last 40 lines of the log.

INSTALL ON YOUR ANDROID PHONE
1. Send app-debug.apk to your phone and open it. Allow "install unknown apps" for the app you opened it from. Play Protect may warn about an unknown developer: choose "Install anyway".
2. Open Sorted > Home > "Read my M-PESA messages" and allow SMS and notifications.
   On Android 13 or newer, if the SMS permission is greyed out: long-press the app icon > App info > three dots > "Allow restricted settings", then try again.
3. Import your statement as before (Add another statement) to merge it with the messages.

WHAT TO TEST
- Messages are read from your inbox (sender containing MPESA) and appear in Home and Activity. Home shows how many were not understood yet.
- Send yourself a small M-PESA payment with the app closed: a notification should appear within seconds, and the transaction is added when you open the app.
- Everything stays on the phone. The only network use is loading the PDF-reading libraries.

Not in this build yet: budgets screens and alerts, live parsing while the app is closed, till/withdrawal/airtime message types.
