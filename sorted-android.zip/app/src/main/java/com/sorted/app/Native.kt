package com.sorted.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import org.json.JSONArray
import org.json.JSONObject

/** Messages that arrive while the app is closed wait here until the app opens. */
object Store {
    private fun prefs(c: Context) = c.getSharedPreferences("queue", Context.MODE_PRIVATE)

    @Synchronized
    fun add(c: Context, body: String, date: Long) {
        val a = JSONArray(prefs(c).getString("m", "[]"))
        a.put(JSONObject().put("body", body).put("date", date))
        prefs(c).edit().putString("m", a.toString()).apply()
    }

    @Synchronized
    fun drain(c: Context): String {
        val s = prefs(c).getString("m", "[]") ?: "[]"
        prefs(c).edit().putString("m", "[]").apply()
        return s
    }
}

object Notify {
    private const val CHANNEL = "mpesa"

    fun post(c: Context, title: String, body: String) {
        val nm = c.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "M-PESA activity", NotificationManager.IMPORTANCE_DEFAULT))
        val open = PendingIntent.getActivity(c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val n = Notification.Builder(c, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title)
            .setContentText(body)
            .setContentIntent(open)
            .setAutoCancel(true)
            .build()
        nm.notify((System.currentTimeMillis() % 100000).toInt(), n)
    }

    /** A one-line preview, e.g. "Received KES 100.00". Full parsing happens in the app. */
    fun summary(t: String): String {
        val amount = Regex("""Ksh\s?([\d,]+(?:\.\d+)?)""", RegexOption.IGNORE_CASE).find(t)?.groupValues?.get(1)
        val kind = when {
            t.contains("received", true) -> "Received"
            t.contains("sent to", true) -> "Sent"
            t.contains("paid to", true) -> "Paid"
            t.contains("Fuliza", true) -> "Fuliza"
            else -> "New message"
        }
        return if (amount != null) "$kind KES $amount" else kind
    }
}
