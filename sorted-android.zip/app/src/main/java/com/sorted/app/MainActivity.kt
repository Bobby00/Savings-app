package com.sorted.app

import android.Manifest
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.webkit.WebViewAssetLoader
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : ComponentActivity() {
    private lateinit var web: WebView
    private var chooser: ValueCallback<Array<Uri>>? = null

    private val pick = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        chooser?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(r.resultCode, r.data))
        chooser = null
    }
    private val perms = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        web.evaluateJavascript("window.onPerms&&window.onPerms()", null)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        setContentView(web)
        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? =
                loader.shouldInterceptRequest(request.url)
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(w: WebView, cb: ValueCallback<Array<Uri>>, p: FileChooserParams): Boolean {
                chooser?.onReceiveValue(null)
                chooser = cb
                pick.launch(p.createIntent())
                return true
            }
        }
        web.addJavascriptInterface(Bridge(), "Android")
        web.loadUrl("https://appassets.androidplatform.net/assets/index.html")
    }

    override fun onResume() {
        super.onResume()
        if (::web.isInitialized) web.evaluateJavascript("window.onResume&&window.onResume()", null)
    }

    inner class Bridge {
        @JavascriptInterface
        fun hasPerms(): Boolean =
            checkSelfPermission(Manifest.permission.READ_SMS) == PackageManager.PERMISSION_GRANTED

        @JavascriptInterface
        fun askPerms() {
            runOnUiThread {
                perms.launch(arrayOf(Manifest.permission.READ_SMS, Manifest.permission.RECEIVE_SMS, Manifest.permission.POST_NOTIFICATIONS))
            }
        }

        /** Every M-PESA message in the inbox, oldest first, as JSON [{body, date}]. */
        @JavascriptInterface
        fun readSms(): String {
            val out = JSONArray()
            contentResolver.query(Uri.parse("content://sms/inbox"), arrayOf("body", "date"), "address LIKE ?", arrayOf("%MPESA%"), "date ASC")?.use { c ->
                while (c.moveToNext()) out.put(JSONObject().put("body", c.getString(0)).put("date", c.getLong(1)))
            }
            return out.toString()
        }

        /** Messages that arrived while the app was closed. */
        @JavascriptInterface
        fun drainQueue(): String = Store.drain(this@MainActivity)

        @JavascriptInterface
        fun notify(title: String, body: String) = Notify.post(this@MainActivity, title, body)
    }
}
