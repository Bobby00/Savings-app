package com.sorted.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony

class SmsReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Telephony.Sms.Intents.SMS_RECEIVED_ACTION) return
        val msgs = Telephony.Sms.Intents.getMessagesFromIntent(intent)
        if (msgs.isNullOrEmpty()) return
        val from = msgs[0].originatingAddress ?: return
        if (!from.contains("MPESA", ignoreCase = true)) return
        val body = msgs.joinToString("") { it.messageBody ?: "" }
        Store.add(context, body, msgs[0].timestampMillis)
        Notify.post(context, "M-PESA", Notify.summary(body))
    }
}
